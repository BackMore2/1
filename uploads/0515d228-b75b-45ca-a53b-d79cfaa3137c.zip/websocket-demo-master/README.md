# websocket-demo

#### 介绍
WebSocket 基于java 和springboot的两种方式实现服务端；使用 html+js实现客户端

#### 软件架构
springboot项目


#### 使用说明

1.  java目录是基于java注解的实现
2.  spring目录是基于spring封装的实现


