package com.mc.wsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
