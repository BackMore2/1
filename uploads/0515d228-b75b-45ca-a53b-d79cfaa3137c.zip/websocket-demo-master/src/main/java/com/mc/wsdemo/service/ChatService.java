package com.mc.wsdemo.service;

import com.mc.wsdemo.entity.ChatMessage;
import com.mc.wsdemo.entity.User;
import com.mc.wsdemo.repository.ChatMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChatService {
    @Autowired
    private ChatMessageRepository chatMessageRepository;

    public ChatMessage saveMessage(User sender, String content, String messageType) {
        ChatMessage message = new ChatMessage();
        message.setSender(sender);
        message.setContent(content);
        message.setMessageType(messageType);
        return chatMessageRepository.save(message);
    }

    public List<ChatMessage> getLast100Messages() {
        PageRequest pageRequest = PageRequest.of(0, 100, Sort.by(Sort.Direction.DESC, "sendTime"));
        return chatMessageRepository.findLast100Messages(pageRequest);
    }
} 