package com.mc.wsdemo.mapper;

import com.mc.wsdemo.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
    void updateUser(User user);
    User findByUsername(String username);
}