package com.mc.wsdemo.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ServerEndpoint("/myWs1")
@Component
public class WebSocketServer {
    private static final Map<String, Session> sessions = new ConcurrentHashMap<>();
    private String sessionId;
    private static final Logger log = LoggerFactory.getLogger(WebSocketServer.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    @OnOpen
    public void onOpen(Session session) {
        this.sessionId = session.getId();
        sessions.put(sessionId, session);
        log.info("新的连接: {}", sessionId);
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        try {
            // 解析接收到的JSON消息
            JsonNode jsonNode = objectMapper.readTree(message);
            String type = jsonNode.get("type").asText();
            
            if ("chat".equals(type)) {
                // 直接转发原始JSON消息给其他用户
                for (Map.Entry<String, Session> entry : sessions.entrySet()) {
                    if (!entry.getKey().equals(sessionId)) {
                        try {
                            entry.getValue().getBasicRemote().sendText(message);
                        } catch (IOException e) {
                            log.error("发送消息失败: {}", e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("处理消息错误: {}", e.getMessage());
        }
    }

    @OnClose
    public void onClose() {
        sessions.remove(sessionId);
        log.info("连接关闭: {}", sessionId);
    }

    @OnError
    public void onError(Session session, Throwable error) {
        log.error("WebSocket错误: {}", error.getMessage());
        sessions.remove(sessionId);
    }
} 